ABHINANDAN VARTHAMAN BIOGRAPHY WEBSITE

Files:
- index.html: main webpage
- style.css: responsive mobile-first styling
- script.js: mobile navigation
- robots.txt: search crawler instructions
- sitemap.xml: sitemap for Google Search
- README.txt: this file

IMPORTANT BEFORE PUBLISHING:
1. Replace https://example.com/ in index.html, robots.txt and sitemap.xml with your real website URL.
2. Upload all files to your hosting provider's public web folder.
3. Verify the site works on Android and desktop.
4. Add the real sitemap URL in Google Search Console after publishing.
